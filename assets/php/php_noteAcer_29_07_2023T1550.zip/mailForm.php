<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (isset($_FILES[0])) {
        $arquivo = $_FILES[0]['name'];

        if (isset($_POST['json'])){
        $json = json_decode($_POST['json']);
        var_dump($json);

        }
    }


}

// recipient email address
$to = "suporte@digitalazul.com.br";

// subject of the email
$subject = "Contato web site Mectronic";

// message body
$message = "<h1>Contato web site</h1>";

// from
$from = "suporte@digitalazul.com.br";

// boundary
$boundary = uniqid();

// header information
$headers = "From: $from\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: multipart/mixed; boundary=\".$boundary.\"\r\n";

// attachment
if (isset($_FILES[0])) {
//$attachment = chunk_split(base64_encode(file_get_contents('file.pdf')));
}
// message with attachment
$message = "--".$boundary."\r\n";
$message .= "Content-Type: text/plain; charset=UTF-8\r\n";
$message .= "Content-Transfer-Encoding: base64\r\n\r\n";
$message .= chunk_split(base64_encode($message));
$message .= "--".$boundary."\r\n";
$message .= "Content-Type: application/octet-stream; name=\"file.pdf\"\r\n";
$message .= "Content-Transfer-Encoding: base64\r\n";
$message .= "Content-Disposition: attachment; filename=\"file.pdf\"\r\n\r\n";

//$message .= $attachment."\r\n";

$message .= "--".$boundary."--";

// send email
if (mail($to, $subject, $message, $headers)) {
    echo "Email with attachment sent successfully.";
} else {
    echo "Failed to send email with attachment.";
}
